class api{
    constructor(url,headers){
        this.url = url;
        this.headers = headers
    }

    getallcards(){
        return fetch(this.url+'/getallcards',this.headers)
            .then(res => res.json())
    }
}

const apis = {
    return: new api('https://web2xd.onrender.com',{
        "Content-type": "application/json",
    }),
}

export default apis