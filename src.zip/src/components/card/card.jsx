import './card.css';

function Card({props}) {
    let card = props
    console.log(card)
    return (
        <li className="place-card">
            <img className="place-card__image" src={card.link} alt="" />
            <button
                aria-label="Remove place"
                className="place-card__delete-button"
                type="button"
            ></button>
            <div className="place-card__description">
                <h2 className="place-card__title">{card.description}</h2>
                <button
                    aria-label="Like place"
                    className="place-card__like-button"
                    type="button"
                ></button>
            </div>
        </li>
    );
}

export default Card;