import './main.css';
import Profile from '../profile/profile';
import CardContainer from '../cardcontainrer/cardContainer';

function Main({props}) {
    return (
        <main className="main">
            <section className="travel">
                <Profile />
            </section>
            <section className="galery">
                <CardContainer props={props} />
            </section>
        </main>
    );
}

export default Main;