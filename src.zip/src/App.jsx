import "./App.css";
import Header from "./components/header/header";
import AppContext from "./components/contexto/appcontext";
import Main from "./components/main/main";
import apis from "./data/class";
import { useEffect, useState } from "react";

function App() {
  const contextValue = {};
  const [cards, sendcards] = useState([]);

  useEffect(() => {
    (async () => {
      await apis.return.getallcards().then((res) => {
        sendcards(res.data);
      }).catch((err) => console.log(err));
    })();

  }, []);

  return (
    <AppContext.Provider value={contextValue}>
      <div className="app">
        <Header />
        <Main props={cards} />
      </div>
    </AppContext.Provider>
  );
}

export default App;
